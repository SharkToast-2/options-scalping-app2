#!/usr/bin/env python3
"""
Complete Schwab Authentication
"""

import requests
import json
import os
from urllib.parse import unquote

def complete_schwab_auth():
    """Complete Schwab OAuth authentication with the provided code"""
    
    # Your Schwab API credentials
    client_id = "1wzwOrhivb2PkR1UCAUVTKYqC4MTNYlj"
    client_secret = "67zvYgAIa8bqWr2v"
    redirect_uri = "https://developer.schwab.com/oauth2-redirect.html"
    
    # The authorization code from the redirect URL
    auth_code = "C0.b2F1dGgyLmNkYy5zY2h3YWIuY29t.VSFO-6rUJBRT6Cm-5V-eKymbndJMK6bhwhhC0maYynE%40"
    
    # Decode the URL-encoded authorization code
    auth_code = unquote(auth_code)
    
    print("🔐 Completing Schwab OAuth Authentication")
    print("=" * 50)
    print(f"Client ID: {client_id}")
    print(f"Auth Code: {auth_code[:20]}...")
    print(f"Redirect URI: {redirect_uri}")
    print()
    
    # Token exchange endpoint
    token_url = "https://api.schwabapi.com/v1/oauth/token"
    
    # Prepare the token request
    token_data = {
        'grant_type': 'authorization_code',
        'client_id': client_id,
        'client_secret': client_secret,
        'code': auth_code,
        'redirect_uri': redirect_uri
    }
    
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
    }
    
    try:
        print("🔄 Exchanging authorization code for access token...")
        response = requests.post(token_url, data=token_data, headers=headers)
        
        print(f"📊 Response Status: {response.status_code}")
        print(f"📄 Response Headers: {dict(response.headers)}")
        print(f"📝 Response Body: {response.text}")
        
        if response.status_code == 200:
            tokens = response.json()
            print("\n✅ Authentication successful!")
            print(f"🔑 Access Token: {tokens.get('access_token', 'N/A')[:20]}...")
            print(f"🔄 Refresh Token: {tokens.get('refresh_token', 'N/A')[:20]}...")
            print(f"⏰ Expires In: {tokens.get('expires_in', 'N/A')} seconds")
            print(f"📋 Token Type: {tokens.get('token_type', 'N/A')}")
            
            # Save tokens to config.json
            config_file = 'config.json'
            try:
                with open(config_file, 'r') as f:
                    config = json.load(f)
            except FileNotFoundError:
                config = {}
            
            # Update Schwab authentication section
            if 'schwab_auth' not in config:
                config['schwab_auth'] = {}
            
            config['schwab_auth'].update({
                'access_token': tokens.get('access_token'),
                'refresh_token': tokens.get('refresh_token'),
                'expires_in': tokens.get('expires_in'),
                'token_type': tokens.get('token_type'),
                'timestamp': tokens.get('timestamp', ''),
                'status': 'authenticated'
            })
            
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=2)
            
            print(f"\n💾 Tokens saved to {config_file}")
            print("🎉 Schwab authentication completed successfully!")
            
            return True
            
        else:
            print(f"\n❌ Authentication failed: {response.status_code}")
            print(f"Error: {response.text}")
            return False
            
    except Exception as e:
        print(f"\n❌ Error during authentication: {e}")
        return False

if __name__ == "__main__":
    success = complete_schwab_auth()
    if success:
        print("\n🚀 You can now use Schwab API features in your application!")
    else:
        print("\n⚠️ Authentication failed. Please check your credentials and try again.") 