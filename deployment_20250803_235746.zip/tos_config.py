#!/usr/bin/env python3
"""
ThinkOrSwim API Configuration
"""

# ThinkOrSwim API Configuration
TOS_CONFIG = {
    "use_real_api": False,  # Set to True to use real API
    "client_id": "your_client_id_here",  # Get from TD Ameritrade Developer Portal
    "username": "your_td_username",  # Your TD Ameritrade username
    "password": "your_td_password",  # Your TD Ameritrade password
}

# Instructions:
# 1. Go to https://developer.tdameritrade.com/
# 2. Create a developer account
# 3. Register a new application
# 4. Copy your client_id here
# 5. Set use_real_api to True
# 6. Add your TD Ameritrade credentials

def get_tos_credentials():
    """Get ThinkOrSwim credentials from config"""
    if TOS_CONFIG["use_real_api"]:
        from tos_api import TOSCredentials
        return TOSCredentials(
            username=TOS_CONFIG["username"],
            password=TOS_CONFIG["password"],
            client_id=TOS_CONFIG["client_id"]
        )
    else:
        return None 